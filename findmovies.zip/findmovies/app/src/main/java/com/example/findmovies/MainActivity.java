package com.example.findmovies;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    RecyclerView trendingview;
    popularmoviedata popularmoviedata;
    public static List<popularmoviedata> popmovielist = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        trendingview=findViewById(R.id.recycletrending);
        String url="https://api.themoviedb.org/3/movie/popular?api_key=d3bf2aee718b2374edaa0b9a3b477cf2&language=en-US&page=1";
        StringRequest request = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                try {
                    JSONObject jsonObject = new JSONObject(response);
                    JSONArray jsonArray=jsonObject.getJSONArray("results");
                    for(int i=0;i<jsonArray.length();i++){
                        JSONObject jsonObject1= jsonArray.getJSONObject(i);
                       // Log.i("name",jsonObject1.getString("title"));
                        String title=jsonObject1.getString("title");
                        String date=jsonObject1.getString("release_date");
                        String lang=jsonObject1.getString("original_language");
                        String poster=jsonObject1.getString("poster_path");
                        String overview=jsonObject1.getString("overview");
                        Integer count=jsonObject1.getInt("vote_count");
                        Integer rate=jsonObject1.getInt("vote_average");
                        Boolean adult =jsonObject1.getBoolean("adult");

                        popularmoviedata=new popularmoviedata(title,date,lang,poster,overview,count,rate,adult);
                        popmovielist.add(popularmoviedata);
                    }





                } catch (JSONException e) {
                    e.printStackTrace();

                }


            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                Toast.makeText(MainActivity.this, error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(request);



    }
}